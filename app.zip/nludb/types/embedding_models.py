class EmbeddingModels:
  QA = "st_msmarco_distilbert_base_v3"
  PARAPHRASE = "st_paraphrase_distilroberta_base_v1"
  SIMILARITY = "st_stsb_roberta_base_v2"
