class OcrModels:
  MS_VISION_DEFAULT = "ocr_ms_vision_default"
