class ClassifierModels:
  HF_ZERO_SHOT_LBART = "zs-hf-facebook-bart-large-mnli"