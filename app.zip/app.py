from typing import Dict
from nludb_app import App, Invocation, Response, ErrorResponse
from nludb_app.app import get, post
from nludb_app.lambda_handler import create_lambda_handler
from nludb import EmbeddingModels, NLUDB

__author__ = "Edward Benson"
__copyright__ = "Edward Benson"
__license__ = "MIT"


# Create an app by extending the App baseclass
#
class QuestionAnsweringApp(App):
  def __init__(self):
    super().__init__()
    self.nludb = NLUDB(
       api_key="YOUR_API_KEY_HERE",
       api_domain="https://api.staging.nludb.com/",
       d_query=True
     )
    self.index = self.nludb.create_index(
      name='TEST_QuestionAnsweringApp',
      model=EmbeddingModels.QA,
      upsert=True
    )

  @post('learn')
  def learn(self, sentence: str = None):
    self.index.insert(sentence, reindex=True)
    return Response()

  @post('ask')
  def ask(self, question: str = None):
    hits = self.index.search(question).data
    return Response(json={'result': hits.hits[0].value})

app = QuestionAnsweringApp()
app_handler = create_lambda_handler(app)

if __name__ == '__main__':
    app.learn("Elmo likes tacos.")
    app.learn("Grover likes pizza.")
    app.learn("Big Bird likes sushi.")
    answer = app.ask("What does Grover like?")
    print(answer)
    assert(answer.string == "Grover likes pizza.")


