from typing import Dict
import json
from nludb_app import Invocation, App
from nludb_app.response import Response, ErrorResponse

def create_lambda_handler(app: App):
  """Wrapper function for an NLUDB app within an AWS Lambda function. 
  """

  def lambda_handler(event: Dict, context: Dict):
    invocation = Invocation.safely_from_dict(event)
    response = app(invocation)

    if type(response) == Response:
      if response.json is not None:
        return dict(
          statusCode=200,
          body=response.json
        )      
      elif response.string is not None:
        return dict(
          statusCode=200,
          body=response.string
        )      
      else:
        return dict(
          statusCode=200
        )
    elif type(response) == ErrorResponse:
      return dict(
        statusCode=response.statusCode,
        body=json.dumps(dict(message=response.message))
      )
    else:
      return dict(
        statusCode=500,
        body=json.dumps(dict(message="Handler provided unknown response type."))
      )
  
  return lambda_handler