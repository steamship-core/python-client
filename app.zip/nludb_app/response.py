from dataclasses import dataclass
from typing import Dict

@dataclass
class AppResponse:
  pass

@dataclass
class Response(AppResponse):
  statusCode: int = 200
  json: Dict = None
  string: str = None

@dataclass
class ErrorResponse(AppResponse):
  statusCode: int = 500
  message: str = "An unknown error happened on the server."
  